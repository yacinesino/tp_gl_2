/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.reglable;


import org.emp.gl.reglable.Reglable;

/**
 *
 * @author islam
 */
public abstract class ConfigState {
    Reglable context;
    private ConfigState(){}
    public ConfigState(Reglable r){
        context = r;
    }

    public abstract void doMode();
    public abstract void doConfig();
    public abstract void doIncrement();
    
}
