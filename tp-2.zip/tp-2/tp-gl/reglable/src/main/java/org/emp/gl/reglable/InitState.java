/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.reglable;
import org.emp.gl.reglable.ConfigState;

/**
 *
 * @author islam
 */
public class InitState extends ConfigState {

    public InitState(Reglable r){
        super(r);
    }
    
    
    public void doMode(){}
    public void doConfig(){
        context.setState(new SecondsSelected(context));
    }
    public void doIncrement(){};
    
}
