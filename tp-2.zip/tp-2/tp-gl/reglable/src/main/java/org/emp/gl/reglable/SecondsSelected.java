/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.reglable;


/**
 *
 * @author islam
 */
public class SecondsSelected extends ConfigState {

     public SecondsSelected(Reglable r){
        super(r);
    }    
    public void doMode(){
        context.setState(new MinutesSelected(context));
    };
    public void doConfig(){
        context.setState(new InitState(context));
    };
    public void doIncrement(){
        context.incrementSeconds();
    };
       
}
