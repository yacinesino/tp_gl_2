/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.watch;

import org.emp.gl.reglable.ConfigState;
import org.emp.gl.reglable.InitState;
import org.emp.gl.reglable.Reglable;
import org.emp.gl.timer.service.impl.withdelegation.TimerServiceImplWithDelegation;


/**
 *
 * @author islam
 */
public class Watch extends TimerServiceImplWithDelegation implements Reglable{
    
    ConfigState state = new InitState(this);
    
    public void doMode(){
        state.doMode();
    };
    public void doConfig(){
        state.doConfig();
    };
    public void doIncrement(){
        state.doIncrement();
    };
    public void setState(ConfigState newState){
        state = newState;
    }
    public void incrementSeconds(){
        setSeconds((getSecondes() + 1) % 60);
    }
    public void incrementMinutes(){
        setMinutes((getMinutes() + 1) % 60);
    }
    public void incrementHours(){
        setHours((getHeures() + 1) % 24);
    }
    
}
