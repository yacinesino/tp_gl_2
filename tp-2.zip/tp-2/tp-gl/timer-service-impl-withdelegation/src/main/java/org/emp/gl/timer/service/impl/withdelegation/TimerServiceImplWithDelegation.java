package org.emp.gl.timer.service.impl.withdelegation;

import java.beans.PropertyChangeSupport;
import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;
import org.emp.gl.timer.service.TimeChangeProvider;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author islam
 */
public class TimerServiceImplWithDelegation extends TimerTask implements TimerService{
    
    private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    
    int dixiemeDeSeconde;
    int minutes;
    int secondes;
    int heures;
    
    final static String DIXEME_DE_SECONDE_PROP = "dixième" ;
    final static String SECONDE_PROP = "seconde" ;
    final static String MINUTE_PROP = "minute" ;
    final static String HEURE_PROP = "heure" ;
    
    
    
    public TimerServiceImplWithDelegation() {
        Timer timer = new Timer();                               

        LocalTime localTime = LocalTime.now();

        secondes = localTime.getSecond();
        minutes = localTime.getMinute();
        heures = localTime.getHour();
        dixiemeDeSeconde = localTime.getNano() / 100000000;

        timer.scheduleAtFixedRate(this, 100, 100);
    }
    
     @Override
    public void run() {
        timeChanged();
    }
    
    @Override
    public void addTimeChangeListener(TimerChangeListener pl) {
        pcs.addPropertyChangeListener(pl); 
    }

    @Override
    public void removeTimeChangeListener(TimerChangeListener pl) {
        pcs.removePropertyChangeListener(pl);
    }
    
    

    @Override
    public int getMinutes() {
        return minutes;
    }

    @Override
    public int getHeures() {
        return heures;
    }

    @Override
    public int getSecondes() {
        return secondes;
    }
    
    
    public void setMinutes(int newMinutes) {
        minutes = newMinutes;
    }

    
    public void setHours(int newHours) {
        heures = newHours;
    }

    
    public void setSeconds(int newSeconds) {
        secondes = newSeconds;
    }
    

    @Override
    public int getDixiemeDeSeconde() {
        return dixiemeDeSeconde;
    }

    private void timeChanged() {
        updateDixiemeDeSecode();
    }

    private void updateDixiemeDeSecode() {
        int oldValue = dixiemeDeSeconde;
        dixiemeDeSeconde = (dixiemeDeSeconde + 1) % 10;

        // informer les listeners ! 
        
            pcs.firePropertyChange(TimerChangeListener.DIXEME_DE_SECONDE_PROP,
                    oldValue, dixiemeDeSeconde);

        if (dixiemeDeSeconde == 0) {
            updateSecode();
        }
    }

    private void updateSecode() {
        int oldValue = secondes;
        secondes = (secondes + 1) % 60;
        
            pcs.firePropertyChange(TimerChangeListener.SECONDE_PROP,
                    oldValue, secondes);
            
        if (secondes == 0) {
            updateMinutes();
        }
    }

    private void updateMinutes() {
        int oldValue = minutes;
        minutes = (minutes + 1) % 60;

        
            pcs.firePropertyChange(TimerChangeListener.MINUTE_PROP,
                    oldValue, minutes);
            

        if (minutes == 0) {
            updateHeures();
        }
    }

    private void updateHeures() {
        int oldValue = heures;
        heures = (heures + 1) % 24;

        
            pcs.firePropertyChange(TimerChangeListener.HEURE_PROP,
                    oldValue, heures);
            
    }
    
}
