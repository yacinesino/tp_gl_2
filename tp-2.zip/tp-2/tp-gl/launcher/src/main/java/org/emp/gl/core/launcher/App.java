package org.emp.gl.core.launcher;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.impl.gui.GuiControl;
import org.emp.gl.impl.gui.GuiImplementation;
import org.emp.gl.reglable.Reglable;
import org.emp.gl.service.gui.GuiService;
import org.emp.gl.timer.service.TimerService;
import org.emp.gl.watch.Watch;



public class App {

    // ce code nous permettra d'enregistrer les service que notre application utilsiera 
    // lors de l'execution
    static {
        Watch watch = new Watch();
        Lookup.getInstance().register(TimerService.class, watch);
        Lookup.getInstance().register(Reglable.class, watch);
    
    }

    public static void main(String[] args) {

        testDuTimeService();
    }


    private static void testDuTimeService() {

        GuiService mGui = new GuiImplementation();
        GuiControl mGuiControl = new GuiControl();
        
    }

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
