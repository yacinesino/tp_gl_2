package org.emp.gl.service.gui;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import org.emp.gl.timer.service.TimerChangeListener;

/**
 *
 * @author islam
 */
public interface GuiService extends TimerChangeListener{
    
    public void display();
    public void activate();
    public void desactivate();
    
}